document.addEventListener('DOMContentLoaded', () => {
  const compra = JSON.parse(localStorage.getItem('ultimaCompra'));
  const nombre = localStorage.getItem('nombreCliente') || 'Cliente';

  if (!compra) {
    alert('No hay ticket disponible.');
    window.location.href = '/';
    return;
  }

  document.getElementById('nombreCliente').textContent = nombre;
  document.getElementById('fechaTicket').textContent = new Date().toLocaleDateString();

  const tbody = document.getElementById('tablaProductos');
  let total = 0;

  compra.productos.forEach(p => {
    const fila = document.createElement('tr');
    const subtotal = p.precio * p.cantidad;
    total += subtotal;

    fila.innerHTML = `
      <td>${p.nombre}</td>
      <td>${p.cantidad}</td>
      <td>$${p.precio.toFixed(2)}</td>
      <td>$${subtotal.toFixed(2)}</td>
    `;
    tbody.appendChild(fila);
  });

  document.getElementById('totalFinal').textContent = total.toFixed(2);
});

function descargarPDF() {
  const elemento = document.getElementById('contenidoTicket');
  const opciones = {
    filename: 'ticket.pdf',
    margin: 0.5,
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: { scale: 2 },
    jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
  };
  html2pdf().from(elemento).set(opciones).save();
}

function reiniciar() {
  localStorage.removeItem('carrito');
  localStorage.removeItem('ultimaCompra');
  window.location.href = '/';
}
