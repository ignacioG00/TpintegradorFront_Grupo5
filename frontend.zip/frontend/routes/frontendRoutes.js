const express = require('express');
const router = express.Router();
const path = require('path');
const { Producto } = require('../models');

// Pantalla de bienvenida
router.get('/', (req, res) => {
  res.render('bienvenida');
});

// Pantalla de productos con paginación
router.get('/productos', async (req, res) => {
  const pagina = parseInt(req.query.pagina) || 1;
  const porPagina = 6;

  const offset = (pagina - 1) * porPagina;

  // Traer productos activos con paginación
  const productosDB = await Producto.findAll({ where: { activo: true } });

  // Agrupar por tipo/categoría
  const categorias = {};
  productosDB.forEach(prod => {
    if (!categorias[prod.tipo]) categorias[prod.tipo] = [];
    categorias[prod.tipo].push(prod);
  });

  const categoriasArray = Object.keys(categorias).map(c => ({
    nombre: c,
    productos: categorias[c].slice(offset, offset + porPagina)
  }));

  const totalPaginas = Math.ceil(productosDB.length / porPagina);

  const nombreUsuario = req.query.nombre || 'Cliente';

  res.render('productos', {
    categorias: categoriasArray,
    paginaActual: pagina,
    totalPaginas,
    nombreUsuario
  });
});

// Carrito de compras
router.get('/carrito', (req, res) => {
  res.render('carrito');
});

// Ticket de compra
router.get('/ticket', (req, res) => {
  res.render('ticket');
});

// Encuesta post-ticket
router.get('/encuesta', (req, res) => {
  res.render('encuesta');
});

// Pantalla de detalle de producto
router.get('/detalle/:id', async (req, res) => {
  const id = req.params.id;
  const producto = await Producto.findByPk(id);

  if (!producto) {
    return res.status(404).render('layouts/404', { mensaje: 'Producto no encontrado' });
  }

  res.render('detalle', { producto });
});

module.exports = router;
