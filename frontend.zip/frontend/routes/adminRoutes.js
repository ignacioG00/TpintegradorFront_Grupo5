const express = require('express');
const router = express.Router();
const { Usuario, Producto, Venta } = require('../models');
const path = require('path');
const multer = require('multer');
const bcrypt = require('bcryptjs');

// Multer para cargar imágenes de productos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../public/uploads/productos'));
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

// Login admin
router.get('/login', (req, res) => {
  res.render('loginAdmin');
});

router.post('/login', async (req, res) => {
  const { correo, contrasena } = req.body;
  const usuario = await Usuario.findOne({ where: { correo } });

  if (!usuario || !bcrypt.compareSync(contrasena, usuario.contrasena)) {
    return res.render('loginAdmin', { error: 'Credenciales inválidas' });
  }

  req.session.admin = usuario.id;
  res.redirect('/admin/dashboard');
});

// Dashboard productos
router.get('/dashboard', async (req, res) => {
  if (!req.session.admin) return res.redirect('/admin/login');
  const productos = await Producto.findAll();
  res.render('dashboard', { productos });
});

// Alta producto
router.get('/alta', (req, res) => {
  if (!req.session.admin) return res.redirect('/admin/login');
  res.render('altaProducto');
});

router.post('/alta', upload.single('imagen'), async (req, res) => {
  const { nombre, precio, tipo } = req.body;
  await Producto.create({
    nombre,
    precio,
    tipo,
    imagen: req.file?.filename || 'default.png',
    activo: true
  });
  res.redirect('/admin/dashboard');
});

// Editar producto
router.get('/editar/:id', async (req, res) => {
  const producto = await Producto.findByPk(req.params.id);
  res.render('editarProducto', { producto });
});

router.post('/editar/:id', upload.single('imagen'), async (req, res) => {
  const { nombre, precio, tipo } = req.body;
  const imagen = req.file?.filename;
  await Producto.update(
    {
      nombre,
      precio,
      tipo,
      ...(imagen && { imagen })
    },
    { where: { id: req.params.id } }
  );
  res.redirect('/admin/dashboard');
});

// Baja lógica
router.post('/baja/:id', async (req, res) => {
  await Producto.update({ activo: false }, { where: { id: req.params.id } });
  res.redirect('/admin/dashboard');
});

// Activar producto
router.post('/activar/:id', async (req, res) => {
  await Producto.update({ activo: true }, { where: { id: req.params.id } });
  res.redirect('/admin/dashboard');
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/admin/login');
});

module.exports = router;

