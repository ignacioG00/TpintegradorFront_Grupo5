module.exports = (sequelize, DataTypes) => {
  return sequelize.define('Encuesta', {
    comentario: DataTypes.TEXT,
    email: DataTypes.STRING,
    volveria: DataTypes.BOOLEAN,
    puntuacion: DataTypes.INTEGER,
    imagen: DataTypes.STRING,
    fecha: DataTypes.DATE
  });
};